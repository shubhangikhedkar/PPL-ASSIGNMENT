def AB(a,b):
    try:
        c=((a+b)/(a-b))
    except ZeroDivisionError:
        print("error occurred!! a  and b should be unequal")
    else:
        print(c)

AB(5,6)
AB(3,3)