
%flights
flight(paries,united,toulouse,35,120).
flight(toulouse,united,paries,35,120).
flight(toronto,aircanada,london,500,360).
flight(london,aircanada,toronto,500,360).
flight(toronto,united,london,650,420).
flight(london,united,toronto,650,420).
flight(toronto,aircanada,madrid,900,480).
flight(madrid,aircanada,toronto,800,340).
flight(toronto,united,madrid,950,600).
flight(madrid,united,toronto,600,400).
flight(madrid,aircanada,barcelone,700,800).
flight(barcelona,iberia,madrid,120,65).
flight(london,iberia,barcelona,110,68).
flight(madrid,iberia,valencia,70,45).
flight(valencia,iberia,madrid,68,700).
flight(malaga,iberia,madrid,600,456).

%Airports
airport(toronto,50,60).
airport(london,70,80).
airport(madrid,75,90).
airport(barcelone,80,50).
airport(valencia,20,90).
airport(malaga,80,20).
airport(paries,80,90).
airport(toulouse,50,90).

/* is there a flight from toronto to madrid? */
pathflight(X,Z) :-
       flight(X,_,Z,_,_).
pathflight(X,Z):-
       flight(X,_,Y,_,_),pathflight(Y,Z).

/* A flight from city A to city B with airline C is cheap if its price less than $400? */
checkflights(A,C,B):-
        flight(A,C,B,D,_),
        D < 400.

/* is it possible to go from toronto to madrid */
twoflights(X,Y):-
        flight(X,_,Z,_,_),flight(Z,_,Y,_,_).

/* A flight from city A to city B with airline C is preferred if it's cheap  or it's with air_canada?*/
preferred(A,C,B):-
          checkcheap(A,C,B);C==aircanada.

/* if there is a flight from city A to city B with united,then there is flight from city A to city B with air_canada? */
flightsearch(A,B):-
          flight(A,united,B,_,_),
          write("yes ,there is flight with airline united"),
          flight(A,aircanada,B,_,_),
          write("yes, there is flight with  airline air_canada").


