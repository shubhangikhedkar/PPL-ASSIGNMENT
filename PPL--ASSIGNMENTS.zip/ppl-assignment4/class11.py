class Bird:
#parent class
    def __init__(self):
        print("bird is ready")

    def whoisthis(self):
        print("Bird")

    def swim(self):
        print("swim faster")
    
class Penguin(Bird):
#child class
    def __init__(self):
        super().__init__()
        print("Penguin is ready")
    def whoisthis(self):
        print("Penguin")
    def run(self):
        print("run faster")

peggy=Penguin()
peggy.whoisthis()
peggy.swim()
peggy.run()
