class wild_animal:

    def __init__(self):
        print("they are dangerous,they can attack on  humans!!")
    
    def move(self):
        print("they can walk and run")

class Tiger(wild_animal):
    

    def __init__(self):
        super().__init__()
        print("Tiger is one of them")

    def sound(self):
        print("tigers can roar")

t=Tiger()
t.move()
t.sound()
    
    
