class cat:

    def __init__(self):
        print("cat's are so cute")

    def voice(self):
        print("there sound is like 'myau'")

    def food(self):
        print(" cats like milk")

class cat1(cat):
    def __init__(self):
        super().__init__()
        print("color of cat1 is brown")

class cat2(cat):
    def __init__(self):
        super().__init__()
        print("color of cat2 is black")

kitty=cat1()
manu=cat2()
kitty.voice()
manu.food()