class Parrot:

    def fly(self):
        print("parrot can fly")
    def swim(self):
        print("parrot can't swim")

class Penguin:

    def fly(self):
        print("penguin can't fly")
    def swim(self):
        print("penguin can swim")

def flying_test(bird):
    bird.fly()

mithu=Parrot()
peggy=Penguin()
flying_test(mithu)
flying_test(peggy)
