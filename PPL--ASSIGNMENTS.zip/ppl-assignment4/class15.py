class cat:
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def info(self):
        print("I am a cat.my name is {}.I am {} years old".format(self.name,self.age))
    
    def make_sound(self):
        print("myau")

class Dog:
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def info(self):
        print("I am a dog.my name is {}.I am {} years old".format(self.name,self.age))
    
    def make_sound(self):
        print("bark")

cat1=cat("manu",5)
dog1=Dog("badal",7)

for animal in (cat1,dog1):
    animal.make_sound()
    animal.info()
    animal.make_sound()
