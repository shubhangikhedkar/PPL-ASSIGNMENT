class shark():
    def swim(self):
        print("the shark is swimming")
    def swim_backwards(self):
        print("the shark cannot swim backwards,but can sink backwards")
    def skeleton(self):
        print("the shark's skeleton is made of cartilage")

class Clownfish():
    def swim(self):
        print("the   Clownfish is swimming")
    def swim_backwards(self):
        print("the Clownfish can swim backwards.")
    def skeleton(self):
        print("the  Clownfish's skeleton is made of bone")

summy=shark()
tummy=Clownfish()



for fish in (summy,tummy):
    fish.swim()
    fish.swim_backwards()
    fish.skeleton()
