class Reptiles:

    def __init__(self):
        print("Reptiles are tetropod animals")
    
    def info(self):
        print("they are cold blooded")

class Lizard(Reptiles):

    def __init__(self):
        Reptiles.__init__(self)
        print("Lizard is Reptile")
    def legs(self):
        print("it has 4 legs")

p=Lizard()
p.info()
p.legs()