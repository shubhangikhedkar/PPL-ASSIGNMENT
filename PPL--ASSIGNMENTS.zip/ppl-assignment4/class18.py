class horse():

    def __init__(self):
        print("It runs very fast")

    def food(self):
        print("it eats grass")

class horse1(horse):
    def __init__(self):
        horse.__init__(self)
        print("its color is black")

class horse2(horse):
    def __init__(self):
        horse.__init__(self)
        print("its color is white")

p=horse1()
t=horse2()
