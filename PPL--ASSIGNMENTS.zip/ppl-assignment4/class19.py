from abc import ABC ,abstractmethod 

class Animal(ABC):

    def singing(self):
        pass
    def dancing(self):
        pass

class human(Animal):

    def singing(self):
        print("we can sing ")
    def dancing(self):
        print("we can dance")

class elephant(Animal):

    def singing(self):
        print("we cannot sing ")
    def dancing(self):
        print("we cannot dance")

h=human()
h.singing()
h.dancing()
e=elephant()
e.singing()
e.dancing()
