class butterfly:
    def __init__(self):
        print("it is very colorfull")
    
    def move(self):
        print("it can fly")
    
class one(butterfly):
    def __init__(self):
        super().__init__()
        print("it's color is pink and yellow")


t=one()
t.move()