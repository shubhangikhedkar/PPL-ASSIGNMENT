import turtle

t=turtle.Turtle()
t.pen(pencolor="blue",fillcolor="red",pensize=10,speed=3)


t.begin_fill()
t.fd(100)
t.left(120)
t.fd(100)
t.left(120)
t.fd(100)
t.end_fill()
