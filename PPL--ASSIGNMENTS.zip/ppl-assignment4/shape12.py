import turtle

t=turtle.Turtle()
t.pen(pencolor="purple",fillcolor="pink",pensize=10,speed=3)


t.begin_fill()
t.circle(70)
t.end_fill()
