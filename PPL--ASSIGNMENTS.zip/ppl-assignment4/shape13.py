import turtle

t=turtle.Turtle()

t.color("blue")


for i in range(50):
    t.fd(50)
    t.left(123)

t.color("red")
for i in range(50):
    t.fd(100)
    t.left(123)