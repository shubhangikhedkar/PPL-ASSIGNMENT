import turtle

t=turtle.Turtle()

for i in range(20):
    t.fd(i*10)
    t.right(144)
