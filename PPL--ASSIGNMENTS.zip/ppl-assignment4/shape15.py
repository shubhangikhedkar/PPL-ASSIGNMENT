import turtle

t=turtle.Turtle()
t.pen(pencolor="purple",fillcolor="yellow",pensize=5,speed=1)

n=6
l=70
angle=360/n
t.begin_fill()
for i in range(n):
    t.fd(l)
    t.right(angle)
t.end_fill()

