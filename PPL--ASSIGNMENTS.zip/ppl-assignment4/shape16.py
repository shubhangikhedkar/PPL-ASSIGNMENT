import turtle

turtle.bgcolor("yellow")

t=turtle.Turtle()
t.pen(pencolor="purple",fillcolor="red",pensize=9,speed=1)

t.begin_fill()
t.circle(40)
t.circle(-40)
t.end_fill()