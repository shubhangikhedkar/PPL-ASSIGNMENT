import turtle

t=turtle.Turtle()


t.rt(60)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(60)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(60)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(60)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(60)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(60)
t.fd(50)
t.lt(120)
t.fd(50)



