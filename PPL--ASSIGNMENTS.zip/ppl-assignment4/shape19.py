
import turtle

t=turtle.Turtle()
t.pen(pencolor="purple",fillcolor="red",pensize=9,speed=1)

t.begin_fill()
t.rt(60)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(120)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(120)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(120)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(120)
t.fd(50)
t.lt(120)
t.fd(50)
t.rt(120)
t.fd(50)
t.lt(120)
t.fd(50)

t.end_fill()

