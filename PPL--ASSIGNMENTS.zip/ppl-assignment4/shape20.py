import turtle

turtle.bgcolor("magenta")
turtle.color("yellow")
turtle.pensize(6)
turtle.rt(180)
turtle.circle(40,180)
turtle.circle(-40,180)

