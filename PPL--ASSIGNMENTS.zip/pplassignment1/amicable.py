import math, numpy
import matplotlib.pyplot as plt

print("\nWelcome to viscometer calculator\n")

def kine_visco(time, a_val, b_val):
	#calculates kinematic viscosity using time
	return a_val*time - b_val/time



# creating an empty list 
time_lst = [] 
temp_lst = [] 
kvisc_lst = []
  
# number of elements as input 
n = int(input("Enter number of readings : ")) 
  
# iterating till the range 
for i in range(0, n): 
    time_ele = float(input("\nEnter time for reading number({}): ".format(i+1))) 
  
    time_lst.append(time_ele) # adding the time element 

    temp_ele = float(input("\nEnter temperature for reading number({}): ".format(i+1))) 
  
    temp_lst.append(temp_ele) # adding the temp element 
    
    kvisc_ele = kine_visco(time_ele, 0.0026, 1.72)
    kvisc_lst.append(temp_ele) # adding the temp element 
              


print("\nreading  temperature  time 	viscosity")

for i in range(0,n):
    print("{}	   {}		{}	".format(i, temp_lst[i], time_lst[i]))


plt.ioff()
plt.plot(time_lst, kvisc_lst)
plt.ylabel('Temperature')
plt.xlabel('Time')
plt.show()