#User guess the number which is randmly choose by computer
def numdigits(n) :
    i = 0
    while n != 0 :
        i = i + 1
        n = int(n / 10)
    return i

import random
if __name__ == "__main__" :
    a = random.randrange(1000)
#    print(a)
    b = numdigits(a)
    print(b," digit number.")
    c = int(input("Enter a number to compare "))
    k = 0
    while 1 :
        if c > a :
            print(c," is greater than number to be guessed ")
            break
        elif c < a :
            print(c," is less than number to be guessed ","Enter another upper bound ")
            c = int(input())
        else :
            k = 1
            print(c," is the correct number ")
            break
    if k == 0 :
        up = c
        low = 10**(b-1)
        num = 0
        while 1 :
            print("Your number lies between ",low," and ",up)
            num = int(input("Enter a number to lower the range "))
            if num < a :
                low = num
            elif num > a :
                up = num
            else :
                print(num," is the correct number ")
                break

