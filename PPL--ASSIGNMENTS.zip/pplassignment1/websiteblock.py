# change hosts path according to your os
hosts_path = "C:\Windows\System32\Drivers\etc\hosts"
# localhosts's IP
redirect = "127.0.0.1"

option = int(input("1.Block\n2.Unblock\n"))
def block():
    website=input("Enter website to be blocked:")
    with open(hosts_path,'r+') as file:
        content = file.read()
        if website in content:
            pass
        else:
            file.write(redirect + "" + website + "\n")
        print("website blocked")

def unblock():
    website = input("Enter website to be unblocked:")
    with open(hosts_path, "r+") as file:
        content = file.readlines()
        file.seek(0)
        for line in content:
            if not any(website in line for website in website):
                file.write(line)
        file.truncate()
    print("website unblocked")

if option == 1:
    block()
if option == 2:
    unblock()