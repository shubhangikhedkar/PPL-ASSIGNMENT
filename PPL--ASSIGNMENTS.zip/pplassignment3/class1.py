class cat(object):
    legs=4
    noofeyes=2
    colorofeyes="brown"
    sound="myau"
    

    def get_legs(self):
        print(self.legs)
    def set_legs(self,nooflegs):
        self.legs=nooflegs
        print(self.legs)
    def get_colorofeyes(self):
        print("color of cat is:{}".format(self.colorofeyes))
    def sound_of_cat(self):
        print("the sound of cat is like {}".format(self.sound))



manu=cat()
manu.get_legs() 
manu.get_colorofeyes() 
manu.sound_of_cat()     
    
        