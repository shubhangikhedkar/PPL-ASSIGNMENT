class butterfly:
    Kingdom="Animalia"
    __color="pink and blue"
    food="nector from floweer"

    def get_kingdom(self):
        print(self.Kingdom)
    def get_color(self):
        print(" it's color is {}".format(self.__color))
    def set_color(self,color):
        self.__color=color
    def get_food(self):
        print("buterfly eats {}".format(self.food))

b=butterfly()
b.get_kingdom()
b.get_color()
b.__color="red and pink"
b.get_color()
b.set_color("red and pink")
b.get_color()
b.get_food()

