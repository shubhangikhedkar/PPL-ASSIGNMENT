class dog:
    sound="bho-bho"
    
    def __init__(self,name):
        self.name=name
        self.__breed="beagle"
    def get_name(self):
        print("name of dog is {}".format(self.name))
    def get_breed(self):
        print("breed is {}".format(self.__breed))
    def get_sound(self):
        print("sound is like {}".format(self.sound))
    def add_new_breed(self,newbreed):
        self.__breed=newbreed

badal=dog("badal")
badal.get_breed()
badal.__breed="Akita"
badal.get_breed()
badal.add_new_breed("Akita")
badal.get_breed()
