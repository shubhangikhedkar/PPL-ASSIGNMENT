from abc import ABC,abstractmethod

class Animal(ABC):
    @abstractmethod
    def eat(self):
        pass

class Tiger(Animal):
    def eat(self):
        print("eats non-veg")

class cow(Animal):
    def eat(self):
        print("eats veg")

t=Tiger()
t.eat()

c=cow()
c.eat()