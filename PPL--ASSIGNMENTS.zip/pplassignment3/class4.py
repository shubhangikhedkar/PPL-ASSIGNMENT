class parrot:

    species="bird"

    def __init__(self,name,age):
        self.name=name
        self.age=age
        self.__color="green"
        self.__food="fruits"

    def get_name(self):
        print("my parrot name is {} ".format(self.name))
    
    def age(self):
        print(self.age)

    def get_color(self):
        print("it's color is {}".format(self.__color))

    def change_color(self,new_color):
        self.__color=new_color
    
    def get_food(self):
        print("it eats {}".format(self.__food))

mithu=parrot("mithu",10)
mithu.get_color()
mithu.__color="white"
mithu.get_color()
mithu.change_color("white")
mithu.get_color()
