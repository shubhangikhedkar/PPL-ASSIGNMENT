class snake:

    species="king cobra"
    kingdom="Animillia"
    food="frogs"
    
    def get_species(self):
        print("species is {}".format(self.species))
    
    def get_kingdom(self):
        print("its kingdom is {}".format(self.kingdom))
    
    def get_food(self):
        print("snakes eats {}".format(self.food))

    def feature(self):
        print("snakes cant hear but can sense vibrations")

cobra=snake()
cobra.get_species()
cobra.get_kingdom()
cobra.get_food()
cobra.feature()



 
