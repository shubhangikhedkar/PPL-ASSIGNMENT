class Tiger:

    kingdom="Animillia"
    legs=4
    eyes=2
    sound="roar"

    def get_kingdom(self):
        print("kingdom of tiger is {}".format(self.kingdom))
    
    def no_of_legs(self):
        print("Tiger has {} legs".format(self.legs))

    def no_of_eyes(self):
        print("it has {} eyes".format(self.eyes))

    def get_sound(self):
        print("it sounds like {}".format(self.sound))
    
    def get_food(self):
        print("Tiger is non vegeterian")

t=Tiger()
t.get_kingdom()
t.get_sound()
t.no_of_legs()
t.no_of_eyes()