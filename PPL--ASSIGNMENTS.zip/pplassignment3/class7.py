class peacock:

    legs=2
    eyes=2
    voice="miyau"

    def no_of_legs(self):
        print(self.legs)

    def no_of_eyes(self):
        print(self.eyes)

    def get_sound(self):
        print("its sound is like {}".format(self.voice))

    def feature(self):
        print("it dances in rain beautifully")

kitty=peacock()
kitty.no_of_eyes()
kitty.no_of_legs()
kitty.get_sound()
kitty.feature()

    
