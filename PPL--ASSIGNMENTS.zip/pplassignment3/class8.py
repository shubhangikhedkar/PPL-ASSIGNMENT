class spider:

    def __init__(self):
        self.__legs=9
        self.__eyes=8
        self.food='insects'

    def no_legs(self):
        print(self.__legs)

    def set_legs(self,legs):
        self.__legs=legs
        
     def no_eyes(self):
        print(self.__eyes)
    
    def get_food(self):
        print("it eats {}".format(self.food))

c=spider()
c.no_legs()
c.__legs=7
c.no_legs()
c.set_legs(7)
c.no_legs()



