from abc import ABC

class Animal(ABC):
    def move(self):
        pass
    def eat(self):
        pass

class human(Animal):
    def move(self):
        print("I can walk and run")
    def eat(self):
        print("I eat both veg and non-veg")

class snake(Animal):
    def move(self):
        print("I can crawl")
    def eat(self):
        print("I eat frogs")

man=human()
man.move()
man.eat()
cobra=snake()
cobra.move()
cobra.eat()
