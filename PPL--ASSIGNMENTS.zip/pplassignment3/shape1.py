import turtle

t=turtle.Turtle()



t.fd(40)
t.left(90)
t.fd(40)
t.left(90)
t.fd(40)
t.left(90)
t.fd(40)
t.left(90)
