import turtle

t=turtle.Turtle()

l=50
w=90

t.fd(l)
t.left(90)
t.fd(w)
t.left(90)
t.fd(l)
t.left(90)
t.fd(w)
t.left(90)