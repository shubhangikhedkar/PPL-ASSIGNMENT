import turtle

t=turtle.Turtle()

r=40

t.circle(r)