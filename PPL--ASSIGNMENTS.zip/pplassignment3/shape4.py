import turtle

t=turtle.Turtle()

t.fd(70)
t.left(120)
t.fd(70)
t.left(120)
t.fd(70)
t.left(120)