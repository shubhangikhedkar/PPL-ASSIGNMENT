import turtle

t=turtle.Turtle()

t.fd(100)
t.left(90)
t.fd(100)
t.left(135)
t.fd(142)
