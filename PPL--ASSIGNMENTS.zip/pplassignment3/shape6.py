import turtle

t=turtle.Turtle()

t.fd(100)
t.left(120)
t.fd(100)
t.left(120)
t.fd(100)

t.penup()
t.right(150)
t.fd(50)

t.pendown()
t.right(90)
t.fd(100)
t.right(120)
t.fd(100)
t.right(120)
t.fd(100)