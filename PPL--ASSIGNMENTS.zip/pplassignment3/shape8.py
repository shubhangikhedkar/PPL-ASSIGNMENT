import turtle

t=turtle.Turtle()

n=6
l=70
angle=360/n

for i in range(n):
    t.fd(l)
    t.right(angle)



