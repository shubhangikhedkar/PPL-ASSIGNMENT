import turtle

p=turtle.Turtle()
p.color("blue")
p.pensize(9)

def my_sqrfunc(size):
    for i in range(4):
        p.fd(size)
        p.left(90)
        size=size-5

my_sqrfunc(146)
my_sqrfunc(126)
my_sqrfunc(106)
my_sqrfunc(86)
my_sqrfunc(86)
my_sqrfunc(66)
my_sqrfunc(46)
my_sqrfunc(26)
